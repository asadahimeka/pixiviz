self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8967c68789dad5082f96",
    "url": "/css/app.6877f79f.css"
  },
  {
    "revision": "6eb3f7ace168cf60c5145787b6fdbc96",
    "url": "/favicon.png"
  },
  {
    "revision": "722c22e06babd7ddae0b93b4dde1c2ed",
    "url": "/fonts/element-icons-common.722c22e0.woff2"
  },
  {
    "revision": "105a65aefa1d1644d4e969a88dfa6ab6",
    "url": "/fonts/element-icons-extra.105a65ae.woff2"
  },
  {
    "revision": "8e471ebe5583d63de7bec6872f339da4",
    "url": "/img/98606454.8e471ebe.jpg"
  },
  {
    "revision": "f2cb643c4302744194bb46c055df2a7d",
    "url": "/img/back.f2cb643c.svg"
  },
  {
    "revision": "cfb3875968f77aa996c0859fc40826e0",
    "url": "/img/home.cfb38759.svg"
  },
  {
    "revision": "61fc9c526f7f36f5639d79ca40ddbb66",
    "url": "/img/link-inline.61fc9c52.svg"
  },
  {
    "revision": "06261fa0135d1d2e9aab94c6d8e84d87",
    "url": "/img/link.06261fa0.svg"
  },
  {
    "revision": "fa29bb9b0b93fee7b167ae1ace589d16",
    "url": "/img/rank.fa29bb9b.svg"
  },
  {
    "revision": "313b47d6797b472db194caf09f6531a2",
    "url": "/index.html"
  },
  {
    "revision": "8967c68789dad5082f96",
    "url": "/js/app.9a9d78fc.js"
  },
  {
    "revision": "5b0328db1c1b494ff8d2",
    "url": "/js/chunk-basic.b19ad6df.js"
  },
  {
    "revision": "f22dd3060790601786e7",
    "url": "/js/chunk-core.659b076f.js"
  },
  {
    "revision": "aa1085d10053bcb64e3e",
    "url": "/js/chunk-element.846855a5.js"
  },
  {
    "revision": "de74a4c498fc164d3c3b",
    "url": "/js/chunk-vendors.4022b754.js"
  },
  {
    "revision": "a76bc9411227049e6ec1c1a2aab462c3",
    "url": "/js/gif.js"
  },
  {
    "revision": "7a0f8ebbb7f041fd0f2b85cb7a014f59",
    "url": "/js/gif.worker.js"
  },
  {
    "revision": "812327dd0011eeb6e771e97871dee7da",
    "url": "/manifest.json"
  },
  {
    "revision": "8e78557b21dd2e35cd77d86c47d5efe5",
    "url": "/robots.txt"
  }
]);